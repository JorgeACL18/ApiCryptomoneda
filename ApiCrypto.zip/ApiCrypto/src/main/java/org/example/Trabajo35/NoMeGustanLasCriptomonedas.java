package org.example.Trabajo35;

import java.io.IOException;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.net.URI;
import java.util.Scanner;
import org.json.JSONArray;
import org.json.JSONObject;

public class NoMeGustanLasCriptomonedas {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.println("Introduce el símbolo o el nombre de la criptomoneda");
        String moneda = sc.nextLine().trim().toLowerCase();
        try{
            HttpClient cliente = HttpClient.newHttpClient();
            HttpRequest request = HttpRequest.newBuilder()
                    .uri(URI.create("https://api.coinlore.net/api/tickers/"))
                    .GET()
                    .build();

            HttpResponse<String> response = cliente.send(request, HttpResponse.BodyHandlers.ofString());

            JSONObject json = new JSONObject(response.body());
            JSONArray data = json.getJSONArray("data");

            boolean encontrada = false;

            for (int i = 0; i < data.length(); i++){
                JSONObject mone = data.getJSONObject(i);
                String nomMoneda = mone.getString("name").toLowerCase();
                String symMoneda = mone.getString("symbol").toLowerCase();

                if (nomMoneda.equals(moneda) || symMoneda.equals(moneda)){
                    encontrada = true;
                    String price = mone.getString("price_usd");
                    int rank = mone.getInt("rank");
                    double c24h = mone.getDouble("percent_change_24h");

                    System.out.println("Datos de la moneda:");
                    System.out.println("- Nombre: " + mone.getString("name"));
                    System.out.println("- Símbolo: " + mone.getString("symbol"));
                    System.out.println("- Precio en USD: " + price);
                    System.out.println("- Rank: " + rank);
                    System.out.println("- Cambio 24h: " + c24h + "%");

                    break;
                }
            }
            if(!encontrada){
                System.out.println("Moneda no encontrada");
            }
        } catch (Exception e) {
            System.out.println("Error: " + e.getMessage());
        }
    }
}
